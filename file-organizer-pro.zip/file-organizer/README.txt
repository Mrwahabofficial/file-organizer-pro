# 📁 FILE ORGANIZER PRO
## By NexaTools — Organize your files automatically!

---

## ✅ What it does:
Automatically sorts your messy files into neat folders!

**Before:**
```
Desktop/
  random.pdf
  photo.jpg
  video.mp4
  notes.txt
  music.mp3
```

**After:**
```
Desktop/
  📄 Documents/  → random.pdf, notes.txt
  🖼️ Images/     → photo.jpg
  🎥 Videos/     → video.mp4
  🎵 Music/      → music.mp3
```

---

## 🚀 How to use:

### Step 1 — Install Python
Download from: https://python.org

### Step 2 — Run the script
Double click `file_organizer.py`
OR open terminal and type:
```
python file_organizer.py
```

### Step 3 — Choose folder
- Desktop
- Downloads
- Or any custom folder

### Step 4 — Preview first!
See what will happen BEFORE moving files!

---

## 📂 File Categories:
| Folder | File Types |
|--------|-----------|
| 📄 Documents | PDF, Word, Excel, PowerPoint |
| 🖼️ Images | JPG, PNG, GIF, PSD |
| 🎥 Videos | MP4, AVI, MKV, MOV |
| 🎵 Music | MP3, WAV, FLAC |
| 💻 Code | Python, JS, HTML, CSS |
| 📦 Archives | ZIP, RAR, 7Z |
| 🎨 Design | AI, Figma, XD |
| 📌 Others | Everything else |

---

## ⚠️ Safety:
- Preview mode available — see before you move!
- Duplicate files are renamed automatically
- Hidden files are never touched

---

*NexaTools — Next Generation Tools* 🚀
