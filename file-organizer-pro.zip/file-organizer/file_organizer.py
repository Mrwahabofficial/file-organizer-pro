# ╔══════════════════════════════════════════════════════╗
# ║         FILE ORGANIZER PRO — NexaTools              ║
# ║         Automatically organize your files!          ║
# ║         Version 1.0                                 ║
# ╚══════════════════════════════════════════════════════╝

import os
import shutil
from datetime import datetime

# ── File Categories ────────────────────────────────────
CATEGORIES = {
    "📄 Documents": [
        ".pdf", ".doc", ".docx", ".txt", ".ppt", ".pptx",
        ".xls", ".xlsx", ".csv", ".odt", ".rtf", ".pages"
    ],
    "🖼️ Images": [
        ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg",
        ".webp", ".ico", ".tiff", ".raw", ".heic", ".psd"
    ],
    "🎥 Videos": [
        ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv",
        ".webm", ".m4v", ".3gp", ".mpeg", ".mpg"
    ],
    "🎵 Music": [
        ".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma",
        ".m4a", ".opus", ".aiff"
    ],
    "💻 Code": [
        ".py", ".js", ".html", ".css", ".java", ".cpp",
        ".c", ".php", ".ts", ".json", ".xml", ".sql",
        ".sh", ".bat", ".rb", ".go", ".swift", ".kt"
    ],
    "📦 Archives": [
        ".zip", ".rar", ".7z", ".tar", ".gz", ".bz2",
        ".xz", ".iso", ".dmg"
    ],
    "⚙️ Executables": [
        ".exe", ".msi", ".apk", ".app", ".deb", ".rpm"
    ],
    "🎨 Design": [
        ".ai", ".fig", ".xd", ".sketch", ".indd",
        ".eps", ".cdr"
    ],
    "📊 Data": [
        ".db", ".sqlite", ".sql", ".json", ".xml",
        ".yaml", ".yml", ".env"
    ],
}


def print_banner():
    print("\n" + "="*55)
    print("   📁  FILE ORGANIZER PRO — NexaTools")
    print("   Automatically organize your messy files!")
    print("="*55 + "\n")


def get_category(extension):
    """Find which category a file belongs to"""
    ext = extension.lower()
    for category, extensions in CATEGORIES.items():
        if ext in extensions:
            return category
    return "📌 Others"


def organize_folder(folder_path, dry_run=False):
    """
    Organize all files in a folder
    dry_run = True means just show what WILL happen (preview)
    dry_run = False means actually move files
    """
    if not os.path.exists(folder_path):
        print(f"  ❌ Folder not found: {folder_path}")
        return

    files = [f for f in os.listdir(folder_path)
             if os.path.isfile(os.path.join(folder_path, f))]

    if not files:
        print("  ⚠️  No files found in this folder!")
        return

    print(f"  📂 Folder  : {folder_path}")
    print(f"  📊 Files   : {len(files)} files found")
    print(f"  🔧 Mode    : {'PREVIEW' if dry_run else 'ORGANIZING'}")
    print("\n" + "-"*55)

    moved   = 0
    skipped = 0
    summary = {}

    for filename in files:
        # Skip hidden files and this script itself
        if filename.startswith('.') or filename.endswith('.py'):
            skipped += 1
            continue

        file_path = os.path.join(folder_path, filename)
        _, ext    = os.path.splitext(filename)

        if not ext:
            category = "📌 Others"
        else:
            category = get_category(ext)

        # Count per category
        if category not in summary:
            summary[category] = []
        summary[category].append(filename)

        # Create category folder
        category_folder = os.path.join(folder_path, category)

        if not dry_run:
            os.makedirs(category_folder, exist_ok=True)

            # Handle duplicate filenames
            dest_path = os.path.join(category_folder, filename)
            if os.path.exists(dest_path):
                name, extension = os.path.splitext(filename)
                timestamp = datetime.now().strftime("%H%M%S")
                filename  = f"{name}_{timestamp}{extension}"
                dest_path = os.path.join(category_folder, filename)

            shutil.move(file_path, dest_path)
            print(f"  ✅ {filename[:35]:<35} → {category}")
        else:
            print(f"  👀 {filename[:35]:<35} → {category}")

        moved += 1

    # Summary
    print("\n" + "="*55)
    print("  📊 SUMMARY:")
    print("-"*55)
    for category, file_list in summary.items():
        print(f"  {category:<25} : {len(file_list)} files")

    print("-"*55)
    print(f"  ✅ Total organized : {moved} files")
    if skipped:
        print(f"  ⏭️  Skipped         : {skipped} files")

    if dry_run:
        print("\n  ℹ️  This was a PREVIEW — no files were moved!")
        print("  Run again and choose 'Yes' to actually organize.")
    else:
        print("\n  🎉 Done! Your folder is now organized!")

    print("="*55 + "\n")


def main():
    print_banner()

    print("  WHERE do you want to organize?")
    print("  ─────────────────────────────")
    print("  1. Desktop")
    print("  2. Downloads folder")
    print("  3. Custom folder path")
    print()

    choice = input("  Enter choice (1/2/3): ").strip()

    if choice == "1":
        folder = os.path.join(os.path.expanduser("~"), "Desktop")
    elif choice == "2":
        folder = os.path.join(os.path.expanduser("~"), "Downloads")
    elif choice == "3":
        folder = input("  Enter full folder path: ").strip()
        folder = folder.strip('"').strip("'")
    else:
        print("  ❌ Invalid choice!")
        return

    print()
    print("  Do you want to PREVIEW first?")
    print("  (See what will happen before actually moving files)")
    preview = input("  Preview first? (yes/no): ").strip().lower()

    print()

    if preview in ["yes", "y"]:
        print("  👀 PREVIEW MODE — No files will be moved\n")
        organize_folder(folder, dry_run=True)

        print()
        confirm = input("  Organize for real now? (yes/no): ").strip().lower()
        if confirm in ["yes", "y"]:
            print()
            organize_folder(folder, dry_run=False)
        else:
            print("\n  ✅ Cancelled. No files were moved!\n")
    else:
        organize_folder(folder, dry_run=False)

    input("\n  Press Enter to exit...")


if __name__ == "__main__":
    main()
